
package za.ac.tut.entity.bl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entity.Student;


@Stateless
public class StudentFacade extends AbstractFacade<Student> implements StudentFacadeLocal {

    @PersistenceContext(unitName = "ClassListEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFacade() {
        super(Student.class);
    }

    @Override
    public Long countMaleAverage() {
     Query query =  em.createQuery("SELECT AVG(s.age) FROM Student s WHERE s.gender='M'  ");
     Long count =(Long) query.getSingleResult();
     return count;
  }

    @Override
    public Long countFemaleAverage() {

     Query query =  em.createQuery("SELECT AVG(s.age) FROM Student s WHERE s.gender='F'  ");
     Long count =(Long) query.getSingleResult();
     return count;
    }

    @Override
    public Long totalMaleStudents() {
        
        Query query =  em.createQuery("SELECT COUNT(s)  FROM Student s WHERE s.gender='M' ");
     Long count =(Long) query.getSingleResult();
     return count;
    }

    @Override
    public Long totalFemaleStudents() {
  
        Query query =  em.createQuery("SELECT COUNT(s)  FROM Student s WHERE s.gender='F' ");
     Long count =(Long) query.getSingleResult();
     return count;
    }

    @Override
    public Student youngestStudent() {
  
        Query query =  em.createQuery("SELECT MIN(s.age)  FROM Student s WHERE s.gender='M' ");
     Student student  =(Student) query.getSingleResult();
     return student;
    }
    
}

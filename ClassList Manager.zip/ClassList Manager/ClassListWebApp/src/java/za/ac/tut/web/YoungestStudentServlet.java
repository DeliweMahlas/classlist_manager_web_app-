
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entity.Student;
import za.ac.tut.entity.bl.StudentFacadeLocal;


public class YoungestStudentServlet extends HttpServlet {

   @EJB
private StudentFacadeLocal sb;
   

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
       Student student =  sb.youngestStudent();
       request.setAttribute("student", student);
        
       RequestDispatcher disp =request.getRequestDispatcher("youngest_student_outcome.jsp");
       disp.forward(request, response);
    }


}

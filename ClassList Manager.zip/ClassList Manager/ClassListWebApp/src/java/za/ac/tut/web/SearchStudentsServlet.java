
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entity.Student;
import za.ac.tut.entity.bl.StudentFacadeLocal;

@MultipartConfig
public class SearchStudentsServlet extends HttpServlet {

 @EJB
 private StudentFacadeLocal sb;
   

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
      Long studNum =Long.parseLong(request.getParameter("studNum"));
      
      String url="index.html";
      
     Student student =  sb.find(studNum);
     
     if(student == null)
     {
         url="student_not_found.jsp";
         
     }
     else
     {
          request.setAttribute("student", student);
        request.setAttribute("studNum", studNum);
        
         url="search_student_outcome.jsp";
     }
     
      
       RequestDispatcher disp =request.getRequestDispatcher(url);
       disp.forward(request, response);
       
    }

    

}

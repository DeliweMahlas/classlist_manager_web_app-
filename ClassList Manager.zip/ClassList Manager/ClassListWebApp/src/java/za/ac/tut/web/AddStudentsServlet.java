
package za.ac.tut.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.util.Collection;
import java.util.Date;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.entity.Student;

import za.ac.tut.entity.bl.StudentFacadeLocal;

@MultipartConfig
public class AddStudentsServlet extends HttpServlet {
@EJB
private StudentFacadeLocal sb;
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String name=request.getParameter("name");
            String surname=request.getParameter("surname");
            Long studNum =Long.parseLong(request.getParameter("studNum"));
            Integer age =Integer.parseInt(request.getParameter("age"));
            
            String gender1 =request.getParameter("gender");
            Character gender =gender1.charAt(0);
            
          
          byte[]image =null;
            
            Collection<Part>parts=request.getParts();
            for(Part x : parts)
            {
                if(x.getContentType() != null)
                {
                   image  = getImageByte(x);
               
                }
            }
            
            Student student = createStudent(name,surname,age,gender,studNum,image);
              sb.create(student);
              
              
              
            RequestDispatcher disp =request.getRequestDispatcher("add_student_outcome.jsp");
            disp.forward(request, response);
    }

    private byte[] getImageByte(Part imagePart) {
        
            InputStream imageInputStream=null;
            byte[] imageBlob=null;
        
        
    try {
       
            imageInputStream = imagePart.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bye_read=0;
        
          while((bye_read =imageInputStream.read(buffer)) != -1)
          {
             baos.write(buffer, 0, bye_read);
          }       
        
          imageBlob=baos.toByteArray();
        
    } 
    catch (IOException ex)
    {
        Logger.getLogger(AddStudentsServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
      return imageBlob;
    }
    
    private Student createStudent(String name, String surname, Integer age, Character gender, Long studNum, byte[] image) {
Student student = new Student();


  student.setId(studNum);
student.setAge(age);
student.setGender(gender);
student.setName(name);
student.setSurname(surname);
student.setCreationDate(new Date());
student.setStudent_image(image);

return student;
    }
}
  
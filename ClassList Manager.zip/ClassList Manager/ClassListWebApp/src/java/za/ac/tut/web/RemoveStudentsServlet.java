
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entity.Student;
import za.ac.tut.entity.bl.StudentFacadeLocal;

@MultipartConfig
public class RemoveStudentsServlet extends HttpServlet {

 @EJB
private StudentFacadeLocal sb;
      

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         Long studNum =Long.parseLong(request.getParameter("studNum"));
        Student student =createStudent(studNum);
        sb.remove(student);
        
        request.setAttribute("studNum",studNum);
        
        RequestDispatcher disp =request.getRequestDispatcher("remove_student_outcome.jsp");
       disp.forward(request, response);
    }

    private Student createStudent(Long studNum) {
    Student student = new Student();
    student.setId(studNum);

    return student;
    }


}
